#ifndef SPI_H
#define SPI_H

#define SPI2		0
#define SPI0		1
#define	HW_EVT1_SPI2			SPI2
#define HW_EVT2_SPI0			SPI0

#define CRC_CALCULATE	0
#define CRC_VERIFY		1
#define RECV_CRC_VERIFY 1

void spi_init(void);
void spi_send_data(void);

void SpiRecevive_Task( void *pvParameters );

void SpiSend_Task( void *pvParameters );

uint8_t crc16_calc(uint8_t *data,uint32_t crc_len,uint8_t calc_verify);

#endif
