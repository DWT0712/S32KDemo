/* ###################################################################
**     Filename    : s32k14x_syslib.c
**     Project     :
**     Processor   : S32K144_100
**     Version     : Driver 01.00
**     Compiler    : GNU C Compiler
**     Date/Time   : 2023-02-09
**     Abstract    :
**         Debug module.
**         This module contains user's debug code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
#include "s32k14x_syslib.h"

volatile stc_fault_frame_t faultFrame;

#if(DEBUG_MODE == D_PRINTF)
void DefaultISR(void)
{
	#define VECTORNUM                     (*(volatile uint8_t*)(0xE000ED04))
	DEBUGprintf("\n****default_isr entered on vector %d*****\r\n\n", VECTORNUM);
	return;
}
#endif

#if(DEBUG_MODE == D_SPRINTF)
void DefaultISR(void)
{
	#define VECTORNUM                     (*(volatile uint8_t*)(0xE000ED04))

	sprintf(buf,"\n****default_isr entered on vector %d  %x *****\r\n\n", (uint8_t)VECTORNUM, (uint32_t)VECTORNUM);
	return;
}
#endif

#if(DEBUG_MODE == D_BX_LR)
void HardFault_Handler(void)
{
	__asm("bx lr");
}
#endif

#if(DEBUG_MODE == D_GET_STACKFRAME)
void getStackFrame(uint32_t *stackFrame)
{
	faultFrame.r0  = stackFrame[0];
	faultFrame.r1  = stackFrame[1];
	faultFrame.r2  = stackFrame[2];
	faultFrame.r3  = stackFrame[3];
	faultFrame.r12 = stackFrame[4];
	faultFrame.lr  = stackFrame[5];
	faultFrame.pc  = stackFrame[6];//�����������pc�����浼���쳣��ָ��ĵ�ַ��
	faultFrame.psr = stackFrame[7];
    __asm("BKPT");  //�ϵ��ж�ָ��
}
void HardFault_Handler(void)
{
	// LR provides information of the return stack PSP/MSP
	__asm("MOVS R0, #4");
	__asm("MOV R1, LR");
	__asm("TST R0, R1");
	__asm("BEQ _MSP");
	__asm("MRS R0, PSP");
	__asm("B getStackFrame");
	__asm("_MSP:");
	__asm("MRS R0, MSP");
	__asm("B getStackFrame");
   //SystemSoftwareReset();
   return;
}
#endif
