/*
 * flexcan.c
 *
 *  Created on: 2023��3��6��
 *      Author: yish
 */
/* Kernel includes. */
//#include "Cpu.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/* SDK includes. */
#include "interrupt_manager.h"
#include "clock_manager.h"
#include "clockMan1.h"
#include "pin_mux.h"

#include <string.h>
#include <stdio.h>

#include "mainConfig.h"
#include "console.h"
#include "flexcan.h"
#include "tja115x.h"
#include "lpit_delay.h"
#include "spi.h"

extern volatile size_t xFreeHeapSpace;
extern QueueHandle_t xSpiReceiveQueue;

SemaphoreHandle_t sem_ReceiveCan;
SemaphoreHandle_t mutex_SendCan;

QueueHandle_t xCanReceiveQueue = NULL;

uint32_t CAN_RX_BufferIndex = 0;    /*buffer index for CAN RX*/
uint32_t CAN_RxDataBufferIndex = 0; /*the latest CAN message data buffer index */
bool CAN_RX_Completed_Flag = false; /*flag used for sync between CAN TXRX ISR and application*/
flexcan_msgbuff_t CAN_RX_Message_Buffer[CAN_RX_Buffer_MAX];/*circle buffer for CAN RX*/

uint32_t CAN_RxFIFO_RX_BufferIndex = 0;    /*buffer index for CAN RxFIFO RX*/
uint32_t CAN_RxFIFO_RxDataBufferIndex = 0; /*the latest RxFIFO CAN message data buffer index */
bool CAN_RxFIFO_RX_Completed_Flag = false; /*flag used for sync between CAN TXRX ISR and application*/
flexcan_msgbuff_t CAN_RxFIFO_RX_Message_Buffer[CAN_RxFIFO_RX_Buffer_MAX];/*circle buffer for CAN RxFIFO RX*/

/*! @brief CAN configuration structure 0 */
const CanComParamsType CAN0_Config =
{
    .instance = 0u,
    .mb_idx = 11u,
    .timeout_ms = 1u
};

/*! @brief CAN configuration structure 1 */
const CanComParamsType TJA115x_CAN_Config =
{
    .instance = 1u,
    .mb_idx = 11u,
    .timeout_ms = 1u
};

bool BusOff_Flag = false; /* the bus off flag */

/* Table of base addresses for CAN instances. */
static CAN_Type * const g_flexcanBasePtr[] = CAN_BASE_PTRS;

/*******************************************************************
  * The CAN TX and RX completed interrupt ISR callback
  *  1) use the new buffer to continue CAN message receive
  *  2) set the RX_Completed_Flag for application handle
  *
  *******************************************************************/
 void CAN_TX_RX_Callback(uint8_t instance, flexcan_event_type_t eventType, uint32_t buffIdx, flexcan_state_t *flexcanState)
 {
	 BaseType_t reschedule;
 	/*check and handle the TX complete event*/
 	if(FLEXCAN_EVENT_TX_COMPLETE==eventType)
 	{
 		/*add your TX complete event handle codes here if needed*/

 	}

 	/*check and handle the RX complete event*/
 	if(FLEXCAN_EVENT_RX_COMPLETE==eventType)
 	{

		CAN_RX_BufferIndex++; /*increase the RX buffer index*/

		if(CAN_RX_BufferIndex >= CAN_RX_Buffer_MAX)
			CAN_RX_BufferIndex = 0; /* reset the index */

		/*use next circle buffer for the new CAN message receive*/
		FLEXCAN_DRV_Receive(instance,buffIdx,&CAN_RX_Message_Buffer[CAN_RX_BufferIndex%CAN_RX_Buffer_MAX]);

		CAN_RX_Completed_Flag = true;/*set the RX completed flag*/

 	}

 	/*
 	 * check whether the RxFIFO receive completed
 	 *
 	 * use FLEXCAN_EVENT_DMA_COMPLETE for DMA event and
 	 * use FLEXCAN_EVENT_RXFIFO_COMPLETE for CPU interrupt event
 	 *
 	 */
 	if((FLEXCAN_EVENT_DMA_COMPLETE==eventType)||(FLEXCAN_EVENT_RXFIFO_COMPLETE==eventType))
 	{
 		CAN_RxFIFO_RX_BufferIndex++; /*increase the RxFIFO RX buffer index*/

 		if(CAN_RxFIFO_RX_BufferIndex >= CAN_RxFIFO_RX_Buffer_MAX)
 			CAN_RxFIFO_RX_BufferIndex = 0; /* reset the index */

		/*use next RxFIFO circle buffer for the new CAN message receive*/
 		FLEXCAN_DRV_RxFifo(instance,&CAN_RxFIFO_RX_Message_Buffer[CAN_RxFIFO_RX_BufferIndex%CAN_RxFIFO_RX_Buffer_MAX]);

 		//DEBUGprintf("callback_can0:\r\n");
		CAN_RxFIFO_RX_Completed_Flag = true;/*set the RxFIFO RX completed flag*/

		xSemaphoreGiveFromISR(sem_ReceiveCan, &reschedule);
		portYIELD_FROM_ISR(reschedule);

 	}
 }
 /*************************************************************************************
  * the CAN error ISR callback
  * user can add handle code for :
  *
  * FlexCAN Error, Error Fast, Tx Warning, Rx Warning and Bus Off as well as Bus Off Done event
  *
  * Note: Here only add the bus-off recovery code for demonstration
  *************************************************************************************/
 void CAN_Error_Callback(uint8_t instance, flexcan_event_type_t eventType,
                                          flexcan_state_t *flexcanState)
 {
 	/* temp variable to store ESR1 register value */
 	uint32_t temp_ESR1_RegVal = 0;

 	DEV_ASSERT(instance < CAN_INSTANCE_COUNT);

 	CAN_Type * base = g_flexcanBasePtr[instance];

 	if(FLEXCAN_EVENT_ERROR==eventType)
 	{
 		/*get the error flags for further process */
 		temp_ESR1_RegVal = FLEXCAN_DRV_GetErrorStatus(instance);


 		if(CAN_ESR1_BOFFINT_MASK&temp_ESR1_RegVal)
 		{
 			/* record the bus off event */
 			BusOff_Flag = true;

 #ifdef CAN_BUSOFF_RECOVERY_MANUAL
 			/* abort current MB transmit */
 			FLEXCAN_DRV_AbortTransfer(INST_CANCOM1,TX_MB);
 #endif  /* end of CAN_BUSOFF_RECOVERY_MANUAL */

 			/* use can add their network management handle codes here  */
 			//PINS_DRV_ClearPins(RGB_LED_GPIO,(1<<RGB_GREEN_LED_PIN)); /*turn ON green RGB LED*/

 			/*get the error flags again in case bus-off recovery have done */
 			temp_ESR1_RegVal = FLEXCAN_DRV_GetErrorStatus(instance);
 		}

 		if(CAN_ESR1_BOFFDONEINT_MASK&temp_ESR1_RegVal)
 		{

 #ifdef CAN_BUSOFF_RECOVERY_MANUAL
			/* the bus off recovery condition(the Tx Error Counter (TXERRCNT) has finished counting 128 occurrences of 11 consecutive recessive bits on the CAN bus and is ready to leave Bus Off) has been detected*/
			/*
			 * clean BOFFREC bit to trigger bus off recovery
			 */
			FLEXCAN_BOFFREC_Config(instance, false);
 #endif  /* end of CAN_BUSOFF_RECOVERY_MANUAL */

			/* wait for the FlexCAN has actually exited bus-off  */
 			while((base->ESR1&CAN_ESR1_FLTCONF_MASK)>=CAN_ESR1_FLTCONF(0x2));

// 			PINS_DRV_SetPins(RGB_LED_GPIO,(1<<RGB_GREEN_LED_PIN)); /*turn OFF green RGB LED*/

 			BusOff_Flag = false; /* clean the flag */

 #ifdef CAN_BUSOFF_RECOVERY_MANUAL
 			/* disable automatic bus-off recovery again */
 			FLEXCAN_BOFFREC_Config(instance, true);
 #endif  /* end of CAN_BUSOFF_RECOVERY_MANUAL */

 		}

 	}
 }
void CAN_User_Init(void)
{
	//ǰ���������ȳ�ʼ��EDMA

#if HW_EVT1
	/* initialize the FlexCAN PD driver */
	FLEXCAN_DRV_Init(INST_FLEXCAN_CONFIG_2, &flexcanState1, &flexcanInitConfig1);

    /* install the error handler call back */
    FLEXCAN_DRV_InstallEventCallback(INST_FLEXCAN_CONFIG_2,CAN_TX_RX_Callback, NULL);

    /* install the FlexCAN error ISR callback, which will also enable error, TX warning, RX warning and bus-off interrupt */
    FLEXCAN_DRV_InstallErrorCallback(INST_FLEXCAN_CONFIG_2, CAN_Error_Callback,NULL);

    INT_SYS_SetPriority(CAN1_ORed_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
    INT_SYS_SetPriority(CAN1_Error_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
    INT_SYS_SetPriority(CAN1_ORed_0_15_MB_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
    INT_SYS_SetPriority(DMA2_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
    //��ʱ�����ˣ���������ID����
    FLEXCAN_DRV_SetRxFifoGlobalMask(INST_FLEXCAN_CONFIG_2, FLEXCAN_RX_FIFO_ID_FORMAT_A, 0);

    FLEXCAN_DRV_RxFifo(INST_FLEXCAN_CONFIG_2, &CAN_RxFIFO_RX_Message_Buffer[0]);
#endif
#if HW_EVT2
    /* initialize the FlexCAN PD driver */
    	FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);

        /* install the error handler call back */
        FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1,CAN_TX_RX_Callback, NULL);

        /* install the FlexCAN error ISR callback, which will also enable error, TX warning, RX warning and bus-off interrupt */
        FLEXCAN_DRV_InstallErrorCallback(INST_CANCOM1, CAN_Error_Callback,NULL);

        /* FreeRTOS�������ж�	*/
        INT_SYS_SetPriority(CAN0_ORed_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
        INT_SYS_SetPriority(CAN0_Error_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
        INT_SYS_SetPriority(CAN0_Wake_Up_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
        INT_SYS_SetPriority(CAN0_ORed_0_15_MB_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
        INT_SYS_SetPriority(CAN0_ORed_16_31_MB_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
        INT_SYS_SetPriority(DMA5_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 1);
        //��ʱ�����ˣ���������ID����
        FLEXCAN_DRV_SetRxFifoGlobalMask(INST_CANCOM1, FLEXCAN_RX_FIFO_ID_FORMAT_A, 0);
        FLEXCAN_DRV_RxFifo(INST_CANCOM1, &CAN_RxFIFO_RX_Message_Buffer[0]);

        //����can����mutex
        mutex_SendCan = xSemaphoreCreateMutex();
        if(mutex_SendCan != NULL)
        {
        	DEBUGprintf("\r\n Createmutex_SendCan OK! \r\n");
        }
        //����can������أ�sem������
    	sem_ReceiveCan = xSemaphoreCreateBinary();
    	if (sem_ReceiveCan == NULL)
    	{
    		DEBUGprintf("ReceiveCan_SendSpiTask: Error creating semaphore\r\n");
    	}
    	//INT_SYS_SetPriority(DMA2_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+2);

    	xCanReceiveQueue = xQueueCreate(CAN_RECEIVE_DATA_TASK_QUEUE, sizeof(CAN_RxFIFO_RX_Message_Buffer));
    	if(xCanReceiveQueue == NULL)
    	{
    		DEBUGprintf("xSpi2ReceiveQueue create failed\r\n");
    	}
    	else
    	{
    		DEBUGprintf("xSpi2ReceiveQueue create success\r\n");
    	}

        //���Ͳ���֡
        uint8_t	data[8] = {0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88};
        g_CAN_send(0x555, &CAN0_Config, CANMSG_STD, 8, data);
#endif
}
#if HW_EVT1
//EVT1 TJA1153 -- CAN1
status_t TJA115x_CAN_Send(uint32_t mailbox, uint32_t messageId, uint8_t *data, uint32_t len)
{
	flexcan_data_info_t dataInfo =
		{
			.data_length = len,
			.msg_id_type = FLEXCAN_MSG_ID_STD,
			.enable_brs  = false,
			.fd_enable   = false,
			.fd_padding  = 0U
		};

	FLEXCAN_DRV_ConfigTxMb(INST_FLEXCAN_CONFIG_2, mailbox, &dataInfo, messageId);
	//return(FLEXCAN_DRV_Send(INST_FLEXCAN_CONFIG_2, mailbox, &dataInfo, messageId, data));  //, 10U));
	return(FLEXCAN_DRV_SendBlocking(INST_FLEXCAN_CONFIG_2, mailbox, &dataInfo, messageId, data, 1U));
}
#endif
/**
 * @brief Helper function to transmit HS CAN with standard or extended CAN identifier.
 *
 * @param CanId        CAN identifier
 * @param CanComParams CAN interface parameters
 * @param CanMsgType   Type of message ID (standard or extended)
 * @param data_len     Data Length Code (max 8)
 * @param data         Pointer to allocated payload data
 *
 * @return TJA115x_NOERROR on successful transmission.
 * @return TJA115x_ERR_NOACK on missing acknowledgment.
 * @return TJA115x_ERR_INVALID on invalid parameter
 */
status_t g_CAN_send(const uint32_t CanId, const CanComParamsType* CanComParams, const CanMsgType CanMsgType, const uint8_t data_len, const uint8_t * const data)
{
	status_t retVal = STATUS_SUCCESS;
    flexcan_msgbuff_id_type_t msg_id_type;

    if (CanMsgType == CANMSG_EXT)
    {
        msg_id_type = FLEXCAN_MSG_ID_EXT;
    }
    else
    {
        msg_id_type = FLEXCAN_MSG_ID_STD;
    }

    /* Set information about the data to be sent
     *  - Message ID
     *  - Bit rate switch disabled
     *  - Flexible data rate disabled
     *  - Use zeros for FD padding
     */
    flexcan_data_info_t dataInfo =
    {
        .data_length = data_len,
        .msg_id_type = msg_id_type,
        .enable_brs  = false,
        .fd_enable   = false,
        .fd_padding  = 0U
    };

    /* Configure TX message buffer with index TX_MSG_ID and TX_MAILBOX*/
    retVal = FLEXCAN_DRV_ConfigTxMb(CanComParams->instance, CanComParams->mb_idx, &dataInfo, CanId);

    /* Execute send non-blocking */
    if (retVal == STATUS_SUCCESS)
    {
#if 1
         retVal = FLEXCAN_DRV_SendBlocking(CanComParams->instance,
                                           CanComParams->mb_idx,
                                           &dataInfo,
                                           CanId,
                                           data,
                                           CanComParams->timeout_ms);
#endif
#if 0
        retVal = FLEXCAN_DRV_Send(	CanComParams->instance,
                			CanComParams->mb_idx,
							&dataInfo,
							CanId,
							data		);
        if(retVal == STATUS_SUCCESS)
        {
        	while((retVal = FLEXCAN_DRV_GetTransferStatus(CanComParams->instance,CanComParams->mb_idx)) == STATUS_BUSY);
        }
#endif
    }
    return retVal;
}
#if HW_EVT1
void TJA115xTask( void *pvParameters )
{
	(void)pvParameters;
	uint8_t SendCandataByte[10];

	DEBUGprintf("\r\n TJA115xTask Start!!! \r\n");
	while(1)
	{
		if (xQueueReceive(xSpi2ReceiveQueue, &SendCandataByte[0], portMAX_DELAY))
		{
			//TJA115x_CAN_Send(TX_MB, SendCandataByte[5], &SendCandataByte[6], 2);
			g_CAN_send(SendCandataByte[5], &TJA115x_CAN_Config, CANMSG_STD, (SendCandataByte[2]-3), &SendCandataByte[6]);
		}
		//OSIF_TimeDelay(10);
	}
}
#endif
#if HW_EVT2
void CAN0_Send_Task( void *pvParameters )
{
	(void)pvParameters;
	uint8_t SendCandataByte[10];

	DEBUGprintf("CAN0_Send_Task Start!!! \r\n");
	while(1)
	{
		if(xSemaphoreTake(mutex_SendCan,portMAX_DELAY) != pdTRUE)
		{
			DEBUGprintf("Fail to take mutex_SendCan \r\n");
		}
		if (xQueueReceive(xSpiReceiveQueue, &SendCandataByte[0], portMAX_DELAY))
		{
			//TJA115x_CAN_Send(TX_MB, SendCandataByte[5], &SendCandataByte[6], 2);
			g_CAN_send(SendCandataByte[5], &CAN0_Config, CANMSG_STD, (SendCandataByte[2]-3), &SendCandataByte[6]);
		}
		//OSIF_TimeDelay(10);
		xSemaphoreGive(mutex_SendCan);
		taskYIELD();
	}
}
#endif
void ReceiveCan_SendSpiTask( void *pvParameters )
{
	(void)pvParameters;
	DEBUGprintf("ReceiveCan_SendSpiTask Start!!! \r\n");
//	sem_ReceiveCan = xSemaphoreCreateBinary();
//	if (sem_ReceiveCan == NULL)
//	{
//		DEBUGprintf("ReceiveCan_SendSpiTask: Error creating semaphore\r\n");
//	}
//	//INT_SYS_SetPriority(DMA2_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+2);
//
//	xCanReceiveQueue = xQueueCreate(CAN_RECEIVE_DATA_TASK_QUEUE, sizeof(CAN_RxFIFO_RX_Message_Buffer));
//	if(xCanReceiveQueue == NULL)
//	{
//		DEBUGprintf("xSpi2ReceiveQueue create failed\r\n");
//	}
//	else
//	{
//		DEBUGprintf("xSpi2ReceiveQueue create success\r\n");
//	}

	while(1)
	{
		/* Wait for transfer to finish */
		xSemaphoreTake(sem_ReceiveCan, portMAX_DELAY);
		if(CAN_RxFIFO_RX_Message_Buffer[0].msgId != 0x5DC)
		{
			if(xQueueSend(xCanReceiveQueue, CAN_RxFIFO_RX_Message_Buffer, (TickType_t)0 ) != pdTRUE)
			{
				DEBUGprintf("xCanReceiveQueue send failed\r\n");
			}
			else
			{
				DEBUGprintf("CAN Recv External.MsgID=%x Data[%x][%x]\r\n",CAN_RxFIFO_RX_Message_Buffer[0].msgId,CAN_RxFIFO_RX_Message_Buffer[0].data[0],CAN_RxFIFO_RX_Message_Buffer[0].data[1]);
			}
		}
		else
		{
			if(CAN_RxFIFO_RX_Message_Buffer[0].data[0] == 0x01)
			{
				DEBUGprintf("Free heap memory: %d Bytes.\n",xFreeHeapSpace);
			}
		}
	}

}

