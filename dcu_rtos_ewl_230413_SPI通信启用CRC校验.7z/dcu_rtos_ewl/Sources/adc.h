#ifndef ADC_H
#define ADC_H

void Adc_Init(void);
float adc0_ch0(void);
float adc1_ch6(void);
void Adc_Task( void *pvParameters );
#endif
