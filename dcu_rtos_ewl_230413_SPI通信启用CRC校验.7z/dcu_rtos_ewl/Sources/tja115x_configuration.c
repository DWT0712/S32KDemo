/*
 * demo_configuration.c
 *
 *  Created on: Aug 26, 2021
 *      Author: nxp74140
 */

#include "clockMan1.h"
#include "pin_mux.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

#include <stdio.h>
#include "console.h"
#include "tja115x.h"
#include "lpit_delay.h"
#include "flexcan.h"

#define mainQUEUE_SEND_FREQUENCY_MS			( 400 / portTICK_PERIOD_MS )
/* Prototypes - supported/demonstrated configuration use cases */
status_t tja115x_local_vanilla_configuration(void);
status_t tja115x_local_vanilla_reconfiguration(void);
status_t tja115x_remote_vanilla_configuration(void);
status_t tja115x_remote_vanilla_reconfiguration(void);
status_t tja115x_reset_vanilla_state(void);	/* Only required for debugging purpose */


/*!
 * @brief TJA115x configuration demonstration
 * @note Application is assumed configured for the clock and Pin settings
 */

Std_ReturnType 	tja115x_main(void) {
//void Tja115xInitTask( void *pvParameters ){

//	(void)pvParameters;

	Std_ReturnType 	trcv_config_ok;

    /* Initialize can controller : CAN1
     * Do not initialize CAN0 (yet) - see later.
     */
//    FLEXCAN_DRV_Init(INST_FLEXCAN_CONFIG_2, &flexcanState1, &flexcanInitConfig1);
//    DEBUGprintf("\r\n[2].CAN1 Init OK! \n");

    /* Initialize UJA1169 SBC as transceiver for CAN0 channel on EVB. */
    /* CAUTION: make sure to supply power to the EVB */
//    LPSPI_DRV_MasterInit(INST_LPSPI_1, &lpspi_1State, &lpspi_0_MasterConfig0);
//    if (UJA1169_Init(INST_LPSPI_1) != STATUS_SUCCESS) {
//    	LED_set(LED_RED);	/* Missing power supply ? */
//    	while(UJA1169_Init(INST_LPSPI_1) != STATUS_SUCCESS);
//    	LED_set(LED_BLACK);
//    }

    /* Initialize can transceiver
     * - CanTrcvInitState = CANTRCV_OP_MODE_STANDBY per default
     */
    CanTrcv_Init(&trcv_tja115x_1_ConfigPtr);

#define	LOCAL_CONFIG_DEMO
#ifdef	LOCAL_CONFIG_DEMO
    /*
     * Demonstrate Vanilla device configuration and re-configuration from local TXD.
     * Remove nodes from CAN network (or reset to listen only)
     */
    if(TJA115X_TIMING) { s_TimeDelay(50); } //���ȥ����ӡ��Ϣ���˴�������Ҫ����ʱ�䣬�����д�ӡ30ms ok

    trcv_config_ok = tja115x_local_vanilla_configuration();

    /* Initialize can controller : CAN0
     * Used as 3rd party CAN node to ack the CONFIG command messages.
     */
//    FLEXCAN_DRV_Init(INST_FLEXCAN_CONFIG_1, &flexcanState0, &flexcanInitConfig0);

    /*
     * Demonstrate Vanilla device re-configuration from local TXD.
     * Make sure the CAN0 channel is also connected to the CAN bus.
     */
//    (void)tja115x_local_vanilla_reconfiguration();

#else	/* LOCAL_CONFIG_DEMO */
    /*
     * Demonstrate Vanilla device configuration from remote CAN bus.
     *
     * NOTE: two nodes are normally used to demonstrate a device configuration from remote.
     * - Node A is performing the configuration and does not (necessarily) contain a TJA115x.
     * - Node B contains the TJA115x to be configured from remote.
     *
     * In this demo, both nodes A and B are implemented by the same hardware (EVBS32K14x + TSB).
     * - Node A is emulated by the usage of CAN channel 0 using the SBC transceiver.
     * - Node B is emulated by the usage of CAN channel 1 using the TJA115x on the TSB.
     */

    /* Node A: Initialize can controller : CAN0
     * Make sure the CAN0 channel is connected to the CAN bus.
     */
    FLEXCAN_DRV_Init(INST_FLEXCAN_CONFIG_1, &flexcanState0, &flexcanInitConfig0);

    /* Node B: Prepare TJA115x transceiver on the TSB for remote configuration. At this time, this program
     * is to be considered as the node (B) with the TJA115x to be configured from remote node (A).
     */
    (void)tja115x_reset_vanilla_state();	/* Only required for debugging purpose */

    /* Node B: Change operating mode to select configuration from remote */
    CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_NORMAL);	// STB=L or STBn=H (and EN=H)

    /* Node A: Perform the configuration from remote. At this time, this program is to be considered as
     * the remote node (A) which assumes the node B transceiver is awaiting for configuration */
    (void)tja115x_remote_vanilla_configuration();

    /* Resulting log on the CAN bus:
     *
     * Mind the Error Frame in messages [3-9] are due to a forced false verification by the driver
     * to check the presence of a TJA115x. The number of Error Frames is influenced by the timeout
     * of trcv_tja115x_1_CANConfig0.
     *
;   Message   Time    Type ID     Rx/Tx
;   Number    Offset  |    [hex]  |  Data Length
;   |         [ms]    |    |      |  |  Data [hex] ...
;   |         |       |    |      |  |  |
;---+-- ------+------ +- --+----- +- +- +- +- -- -- -- -- -- -- --
      1     13826.528 DT     0555 Rx 0
      2     13826.800 DT 18DA00F1 Rx 6  10 00 50 00 07 FF
      3     13827.059 ER          Rx    02 01 1B 00 00
      4     13827.319 ER          Rx    02 01 1B 00 00
      5     13827.579 ER          Rx    02 01 1B 00 00
      6     13827.839 ER          Rx    02 01 1B 00 00
      7     13828.099 ER          Rx    02 01 1B 00 00
      8     13828.359 ER          Rx    02 01 1B 00 00
      9     13828.619 ER          Rx    02 01 1B 00 00
     10     13828.895 DT 18DA00F1 Rx 6  90 00 50 00 07 FF
     11     13829.165 DT 18DA00F1 Rx 6  10 01 9F FF FF FF
     12     13829.437 DT 18DA00F1 Rx 6  90 01 9F FF FF FF
     13     13829.710 DT 18DA00F1 Rx 6  10 02 C0 00 00 00
     14     13829.982 DT 18DA00F1 Rx 6  90 02 C0 00 00 00
     15     13830.184 DT 18DA00F1 Rx 2  40 03
     16     13830.384 DT 18DA00F1 Rx 2  C0 03
     17     13830.599 DT 18DA00F1 Rx 3  50 11 AB
     18     13830.815 DT 18DA00F1 Rx 3  D0 11 AB
     19     13831.061 DT 18DA00F1 Rx 5  60 98 DA 00 F1
     20     13831.307 DT 18DA00F1 Rx 5  E0 98 DA 00 F1
     21     13831.610 DT 18DA00F1 Rx 8  71 02 03 04 05 06 07 08
     */

    /* Node A: Perform the reconfiguration from remote. At this time, this program is to be considered as
     * the remote node (A) which assumes the node B transceiver is awaiting for configuration in Normal mode*/
    (void)tja115x_remote_vanilla_reconfiguration();

    /* Resulting log on the CAN bus:
     *
     * Mind the Error Frame in messages [3-11] are due to an impossible programming counter
     * verification (command byte 0xF0) used to check the correct activation of the configuration mode.
     * The Error Frame in messages [13-19] are due to forced false verification by the driver
     * to check the presence of a TJA115x. The number of Error Frames is influenced by the timeout
     * of trcv_tja115x_1_CANConfig0.
     *
;-------------------------------------------------------------------------------
;   Message   Time    Type ID     Rx/Tx
;   Number    Offset  |    [hex]  |  Data Length
;   |         [ms]    |    |      |  |  Data [hex] ...
;   |         |       |    |      |  |  |
;---+-- ------+------ +- --+----- +- +- +- +- -- -- -- -- -- -- --
      1      6158.647 DT 18DA00F1 Rx 0
      2      6268.324 DT 18DA00F1 Rx 0
      3      6268.532 ER          Rx    02 01 1B 00 00
      4      6268.742 ER          Rx    02 01 1B 00 00
      5      6268.952 ER          Rx    02 01 1B 00 00
      6      6269.162 ER          Rx    02 01 1B 00 00
      7      6269.372 ER          Rx    02 01 1B 00 00
      8      6269.582 ER          Rx    02 01 1B 00 00
      9      6269.792 ER          Rx    02 01 1B 00 00
     10      6270.002 ER          Rx    02 01 1B 00 00
     11      6270.212 ER          Rx    02 01 1B 00 00
     12      6270.486 DT 18DA00F1 Rx 6  10 00 50 00 07 FF
     13      6270.744 ER          Rx    02 01 1B 00 00
     14      6271.004 ER          Rx    02 01 1B 00 00
     15      6271.283 ER          Rx    02 01 1A 00 00
     16      6271.559 ER          Rx    02 01 1A 00 00
     17      6271.835 ER          Rx    02 01 1A 00 00
     18      6272.111 ER          Rx    02 01 1A 00 00
     19      6272.388 ER          Rx    02 01 1A 00 00
     20      6272.678 DT 18DA00F1 Rx 6  90 00 50 00 07 FF
     21      6272.948 DT 18DA00F1 Rx 6  10 01 9F FF FF FF
     22      6273.220 DT 18DA00F1 Rx 6  90 01 9F FF FF FF
     23      6273.492 DT 18DA00F1 Rx 6  10 02 C0 00 00 00
     24      6273.765 DT 18DA00F1 Rx 6  90 02 C0 00 00 00
     25      6273.967 DT 18DA00F1 Rx 2  40 03
     26      6274.167 DT 18DA00F1 Rx 2  C0 03
     27      6274.381 DT 18DA00F1 Rx 3  50 11 AB
     28      6274.598 DT 18DA00F1 Rx 3  D0 11 AB
     29      6274.844 DT 18DA00F1 Rx 5  60 98 DA 00 F1
     30      6275.090 DT 18DA00F1 Rx 5  E0 98 DA 00 F1
     31      6275.392 DT 18DA00F1 Rx 8  71 02 03 04 05 06 07 08
     */
#endif /*!LOCAL_CONFIG_DEMO */
#if AFTER_INIT_SEND_TEST_DATA
    status_t sta_send;
    if(trcv_config_ok == E_OK)  //�ϵ��趨�ڴ˴��ſ��Գɹ��������ݣ�
    {
		/* Try to send a message through the TJA115x on CAN channel 1 */

		{
//			flexcan_data_info_t dataInfo =
//			{
//				.data_length = 8U,
//				.msg_id_type = FLEXCAN_MSG_ID_STD,
//				.enable_brs  = false,
//				.fd_enable   = false,
//				.fd_padding  = 0U
//			};
			uint8_t	data[8] = {1,2,3,4,5,6,7,8};

//			FLEXCAN_DRV_ConfigTxMb(INST_FLEXCAN_CONFIG_2, 11U, &dataInfo, 0x123);
//			sta_send = FLEXCAN_DRV_SendBlocking(INST_FLEXCAN_CONFIG_2, 11U, &dataInfo, 0x123, data, 10U);
			sta_send = TJA115x_CAN_Send(TX_MB, TX_MSG_ID, data, 6);
			DEBUGprintf("\r\n tja SendData 1st = %d \r\n",sta_send);
//			data[0] = 2;
//			sta_send = TJA115x_CAN_Send(TX_MB, TX_MSG_ID, data, 8);
//			DEBUGprintf("\r\n tja SendData 2nd = %d \r\n",sta_send);
		}
    }
    else
    {
    	DEBUGprintf("\r\n[3].TJA1153 Init Fail RET = %d \r\n",trcv_config_ok);
    }
#endif
    return(trcv_config_ok);

//    vTaskSuspend(NULL);
}

/*!
 * @brief Perform the configuration of a Vanilla device from local TXD
 * CanTrcv is assumed initialized.
 *
 * @CAUTION Make sure to remove any 3rd party node from the CAN bus to avoid confusing
 * interpretation of the baud rate detection based on missing acknowledge from the TJA115x device.
 */
status_t tja115x_local_vanilla_configuration(void) {
    tja115x_error_code_t ErrorCode;
    status_t retVal;

    /* Change operating mode to select configuration from local */
    CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_STANDBY);	// STB=H or STBn=L (and EN=L)

    /* Perform the configuration (trcv_tja115x_1_DevCfgCmds0)
     * - with default CONFIG_ID (0x18DA00F1)
     * - on a Vanilla device (CANTRCV_DEVCFG_VANILLA)
     * - from local (trcv_tja115x_1_CANConfig1)
     * - LocalTransceiver (CANTRCV_DEVICE_UNDEF) is not required for the initial vanilla configuration
     * - in volatile memory to keep a Vanilla device (trcv_tja115x_1_DevCfgCmds0.LeaveMode = TJA115x_LEAVE_VOLATILE)
     */
    retVal = CanTrcv_Exts_ConfigureDevice(TJA115x_CMD60_CONFIG_ID_DEFAULT,
    		&trcv_tja115x_1_CANConfig1, &trcv_tja115x_1_DevCfgCmds0, CANTRCV_DEVCFG_VANILLA, CANTRCV_DEVICE_UNDEF, &ErrorCode);

    /* Immediately (< t_h = 1s) enable Normal mode to avoid a warmboot via Standby */
    CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_NORMAL);	// STB=L or STBn=H (and EN=H)
    /*
     * A failure to configure a Vanilla device with baud rate detection error is possible during debugging!
     * During a debug session, the device may have been configured already and baud rate detection fails
     * on a configured device. The vanilla device is configured once when the boards (EVB+TSB) are powered
     * and immediately runs the flashed program including the (above) vanilla configuration.
     * The forthcoming debug session may replace the program in the flash but won't power cycle the TJA115x device.
     *
     * The following code enforces a warm boot of the device to accept again a vanilla configuration
     */
#if 1
    if ((retVal != STATUS_SUCCESS) && (ErrorCode == TJA115x_ERR_BAUDRATE)) {

    	DEBUGprintf("\r\n[2].TJA1153 reset =%d:%d \n",retVal,ErrorCode);
    	/* Force a low-power reset with StandBy mode and 1s bus silence (+20% margin) */
        CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_STANDBY);	// STBn=L or STB=H
        if(DELAY_TYPE == SNAIL_OSIF)
        {
        	s_TimeDelay(1200);
        }
        else
        {
        OSIF_TimeDelay(1200);	/* Delay to enter low-power, leaving Secure Standby mode to reach Standby mode */
        }
        DEBUGprintf("\r\n[2].OSIF_TimeDelay 1 \n");
    	/* Wake-up by Normal mode, warm boot getting out of low-lower */
    	CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_NORMAL);	// STBn=H or STB=L

    	if(DELAY_TYPE == SNAIL_OSIF)
		{
    		s_TimeDelay(100);
		}
		else
		{
    	OSIF_TimeDelay(100);	/* Delay for warm boot completion  */
		}
    	/* Select interface for local Vanilla configuration */
    	CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_STANDBY);	// STBn=L or STB=H

    	/* Perform again a Vanilla device configuration from local */
        retVal = CanTrcv_Exts_ConfigureDevice(TJA115x_CMD60_CONFIG_ID_DEFAULT,
        		&trcv_tja115x_1_CANConfig1, &trcv_tja115x_1_DevCfgCmds0, CANTRCV_DEVCFG_VANILLA, CANTRCV_DEVICE_UNDEF, &ErrorCode);

        /* Immediately (< t_h = 1s) enable Normal mode to avoid a warmboot via Standby */
        CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_NORMAL);	// STB=L or STBn=H (and EN=H)
    }
#endif
    DEBUGprintf("\r\n TJA1153 Result=%d:Ecode=%d\n",retVal,ErrorCode);
    return retVal;
}

/*!
 * @brief Perform a re-configuration of a Vanilla device from local TXD
 * CanTrcv is assumed initialized and device is already configured in non-volatile memory (TJA115x_LEAVE_VOLATILE)
 * and accept re-configuration from local (TJA115x_CMD60_LCLREMn_CONFIG_LOC).
 */
status_t tja115x_local_vanilla_reconfiguration(void) {
    tja115x_error_code_t ErrorCode;
    status_t retVal;

    /* Change operating mode to allow reconfiguration from local TXD */
    CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_NORMAL);	// STB=L or STBn=H (and EN=H)

    /* Perform the configuration (trcv_tja115x_1_DevCfgCmds0)
     * - with default CONFIG_ID (0x18DA00F1)
     * - from local (trcv_tja115x_1_CANConfig1 and CANTRCV_DEVCFG_LOCAL)
     * - LocalTransceiver (CANTRCV_DEVICE0) is required for a local re-configuration on vanilla device.
     *   The operating mode must be changed by the driver to select LOCAL_CONFIG with CANTRCV_TRCVMODE_STANDBY (STBn=L or STB=H)
     *   (cfr. datasheet figure "Vanilla device configuration flow")
     * - in volatile memory to keep a Vanilla device (trcv_tja115x_1_DevCfgCmds0.LeaveMode = TJA115x_LEAVE_VOLATILE)
     */
    retVal = CanTrcv_Exts_ConfigureDevice(TJA115x_CMD60_CONFIG_ID_DEFAULT,
    		&trcv_tja115x_1_CANConfig1, &trcv_tja115x_1_DevCfgCmds0, CANTRCV_DEVCFG_LOCAL, CANTRCV_DEVICE0, &ErrorCode);

    /* Immediately (< t_h = 1s) enable Normal mode to avoid a Warmboot via Standby.
     * The operating mode was changed to CANTRCV_TRCVMODE_STANDBY by the driver with the LocalTransceiver argument */
    CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_NORMAL);	// STB=L or STBn=H (and EN=H)

    /*
     * Note: when retVal != STATUS_SUCCESS and ErrorCode == TJA115x_ERR_LOC_REQ, the CONFIG command messages are most
     * probably not acknowledged due to missing 3rd part node on the CAN bus. Mind that the second CAN channel (initialized)
     * of the S33K14xEVB may used to ack the CONFIG command messages.
     */

    return retVal;
}

/*!
 * @brief Perform a configuration of a Vanilla device from remote CAN bus
 * CanTrcv is assumed initialized and awaiting to be configured from remote (CANTRCV_TRCVMODE_NORMAL)
 */
status_t tja115x_remote_vanilla_configuration(void) {
    tja115x_error_code_t ErrorCode;
    status_t retVal;

    /* Perform the configuration (trcv_tja115x_1_DevCfgCmds1 where TJA115x_CMD60_LCLREMn = CONFIG_REM)
     * - with default CONFIG_ID (0x18DA00F1)
     * - from remote (trcv_tja115x_1_CANConfig0)
     * - LocalTransceiver (CANTRCV_DEVICE_UNDEF) is not required for a remote configuration
     * - in volatile memory to keep a Vanilla device (trcv_tja115x_1_DevCfgCmds0.LeaveMode = TJA115x_LEAVE_VOLATILE)
     */
    retVal = CanTrcv_Exts_ConfigureDevice(TJA115x_CMD60_CONFIG_ID_DEFAULT,
    		&trcv_tja115x_1_CANConfig0, &trcv_tja115x_1_DevCfgCmds1, CANTRCV_DEVCFG_VANILLA, CANTRCV_DEVICE_UNDEF, &ErrorCode);

    return retVal;
}

status_t tja115x_remote_vanilla_reconfiguration(void) {
    tja115x_error_code_t ErrorCode;
    status_t retVal;

    /* Perform the configuration (trcv_tja115x_1_DevCfgCmds0)
     * - with default CONFIG_ID (0x18DA00F1)
     * - from remote (trcv_tja115x_1_CANConfig0)
     * - LocalTransceiver (CANTRCV_DEVICE_UNDEF) is not required for a remote configuration
     * - in volatile memory to keep a Vanilla device (trcv_tja115x_1_DevCfgCmds0.LeaveMode = TJA115x_LEAVE_VOLATILE)
     */
    retVal = CanTrcv_Exts_ConfigureDevice(TJA115x_CMD60_CONFIG_ID_DEFAULT,
    		&trcv_tja115x_1_CANConfig0, &trcv_tja115x_1_DevCfgCmds0, CANTRCV_DEVCFG_REMOTE, CANTRCV_DEVICE_UNDEF, &ErrorCode);

    return retVal;
}

/*!
 * @brief Reset the TJA115x to initial vanilla state
 * @note: Only required for debugging purpose!
 * *
 * The function is forcing a Warmboot of a Vanilla device.
 */
status_t tja115x_reset_vanilla_state(void) {

	/* Force a low-power reset with StandBy mode and 1s bus silence (+20% margin) */
    CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_STANDBY);	// STBn=L or STB=H
    if(DELAY_TYPE == SNAIL_OSIF)
	{
		s_TimeDelay(1200);
	}
	else
	{
    OSIF_TimeDelay(1200);	/* Delay to enter low-power, leaving Secure Standby mode to reach Standby mode */
    }
	/* Wake-up by Normal mode, warm boot getting out of low-lower */
	CanTrcv_SetOpMode(CANTRCV_DEVICE0, CANTRCV_TRCVMODE_NORMAL);	// STBn=H or STB=L

	if(DELAY_TYPE == SNAIL_OSIF)
	{
		s_TimeDelay(100);
	}
	else
	{
	OSIF_TimeDelay(100);	/* Delay for warm boot completion  */
	}
	return STATUS_SUCCESS;
}

