#include "adc.h"
#include "Cpu.h"
#include "console.h"
#include <stdio.h>
#include <string.h>

uint16_t adcMax;
uint16_t adcRawValue0;
uint16_t adcRawValue1;
float adcValue1;
float adcValue2;
#define ADC_VREFH 3.3f
#define ADC_VREFL 0.0f
void Adc_Init(void)
{
	//��������ѡ������
	if(adConv1_ConvConfig0.resolution == ADC_RESOLUTION_8BIT)
	{
		adcMax = (uint16_t)(1<<8);
	}
	else if(adConv1_ConvConfig0.resolution == ADC_RESOLUTION_10BIT)
	{
		adcMax = (uint16_t)(1<<10);
	}
	else
	{
		adcMax = (uint16_t)(1<<12);
	}


	ADC_DRV_ConfigConverter(INST_ADCONV1, &adConv1_ConvConfig0);//adc0��ʼ��
	ADC_DRV_AutoCalibration(INST_ADCONV1);//adc0У׼

	ADC_DRV_ConfigConverter(INST_ADCONV2, &adConv2_ConvConfig0);//adc1��ʼ��
	ADC_DRV_AutoCalibration(INST_ADCONV2);//adc1У׼


}

float adc0_ch0(void)
{
	//ͨ������
	ADC_DRV_ConfigChan(INST_ADCONV1, 0, &adConv1_ChnConfig0);
	//�ȴ�ת�����
	ADC_DRV_WaitConvDone(INST_ADCONV1);
	//��ȡͨ�����
	ADC_DRV_GetChanResult(INST_ADCONV1,0u,&adcRawValue0);
	//��ȡת�����
	adcValue1 = ((float)adcRawValue0/adcMax)*(ADC_VREFH - ADC_VREFL);
	return adcValue1;
}
float adc1_ch6(void)
{
	//ͨ������
	ADC_DRV_ConfigChan(INST_ADCONV2, 0, &adConv2_ChnConfig0);
	//�ȴ�ת�����
	ADC_DRV_WaitConvDone(INST_ADCONV2);
	//��ȡͨ�����
	ADC_DRV_GetChanResult(INST_ADCONV2,0u,&adcRawValue1);
	//��ȡת�����
	adcValue2 = ((float)adcRawValue1/adcMax)*(ADC_VREFH - ADC_VREFL);
	return adcValue2;
}

void Adc_Task( void *pvParameters )
{
	// Casting pvParameters to void because it is unused
	(void)pvParameters;
	Adc_Init();

	for(;;)
	{
		//adc0_Value = adc0_ch0();
		//adc1_Value = adc1_ch6();
		//printf("adc_task value1=%f,value2=%f\r\n",adc0_Value,adc1_Value);
		printf("adc_interrupt\r\n");
		OSIF_TimeDelay(1000);
	}


}














