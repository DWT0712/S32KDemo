/*
 * flexcan.h
 *
 *  Created on: 2023��3��6��
 *      Author: yish
 */

#ifndef FLEXCAN_H_
#define FLEXCAN_H_

#define CAN_RECEIVE_DATA_TASK_QUEUE   	3

//TX_MB = 10 ����tja1153оƬ
#define TX_MB  		11         /*define the TX MB*/
#define TX_MSG_ID	0x100

#define CAN_RX_Buffer_MAX         1   /*define the RX buffer size*/
#define CAN_RxFIFO_RX_Buffer_MAX  1   /*define the RxFIFO RX buffer size*/

typedef struct
{
  uint8_t     instance;   /*!< Used CAN instance for configuration.               */
  uint8_t     mb_idx;     /*!< Index of the message buffer used for transmission. */
  uint32_t    timeout_ms; /*!< A timeout for the transmission in milliseconds.    */
} CanComParamsType;

typedef enum
{
    CANMSG_STD = 0U,
    CANMSG_EXT = 1U
} CanMsgType;
void CAN_User_Init(void);

status_t TJA115x_CAN_Send(uint32_t mailbox, uint32_t messageId, uint8_t *data, uint32_t len);

status_t g_CAN_send(const uint32_t CanId, const CanComParamsType* CanComParams, const CanMsgType CanMsgType, const uint8_t data_len, const uint8_t * const data);
#if HW_EVT1
void TJA115xTask( void *pvParameters );
#endif
#if HW_EVT2
void CAN0_Send_Task( void *pvParameters );
#endif
void ReceiveCan_SendSpiTask( void *pvParameters );
#endif /* FLEXCAN_H_ */
