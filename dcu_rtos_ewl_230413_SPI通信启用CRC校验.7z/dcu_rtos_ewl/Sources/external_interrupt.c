#include "external_interrupt.h"
#include "Cpu.h"
#include "console.h"
#include <stdio.h>
#include <string.h>

uint8_t PTD4_interrupt;
uint8_t PTB5_interrupt;

SemaphoreHandle_t spi_m4_1_sem;

//�ⲿ�жϳ�ʼ��
void External_interrupt_init(void)
{
	//�����жϴ��������������ش���
	//PINS_DRV_SetPinIntSel(PORTD,4,PORT_INT_RISING_EDGE);
	//PINS_DRV_SetPinIntSel(PORTB,5,PORT_INT_RISING_EDGE);
	PINS_DRV_SetPinIntSel(PORTC,10,PORT_INT_RISING_EDGE);
	//���ò�ʹ���жϺ���
	//INT_SYS_InstallHandler(PORTD_IRQn,&PTD_EXT_IRQ,NULL);   //��װ�жϺ���PTD_EXT_IRQ
	//INT_SYS_InstallHandler(PORTB_IRQn,&PTB_EXT_IRQ,NULL);   //��װ�жϺ���PTB_EXT_IRQ
	INT_SYS_InstallHandler(PORTC_IRQn,&PTC_EXT_IRQ,NULL);   //��װ�жϺ���PTC_EXT_IRQ

	//INT_SYS_SetPriority(PORTD_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+2);
	INT_SYS_SetPriority(PORTC_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+2);
	spi_m4_1_sem = xSemaphoreCreateBinary();
	if (spi_m4_1_sem == NULL)
	{
		DEBUGprintf("LPSPI2 slaveTask: Error creating semaphore\r\n");
	}

	//ʹ���ж�
	//INT_SYS_EnableIRQ(PORTD_IRQn);
	//INT_SYS_EnableIRQ(PORTB_IRQn);
	INT_SYS_EnableIRQ(PORTC_IRQn);

}

void PTD_EXT_IRQ (void)
{
	  uint32_t buttonsPressed = PINS_DRV_GetPortIntFlag(PORTD) & ( ( 1 <<4 ) );  //��ȡ�жϱ�־λ״̬
	  BaseType_t reschedule;
	  //����ж�
	  if(buttonsPressed !=0 )
	  {
		  if( ((buttonsPressed >>4) & 0x01) == 1 )
		  {
			  //PTD4_interrupt = 1;
			  xSemaphoreGiveFromISR(spi_m4_1_sem, &reschedule);
			  DEBUGprintf("PTD_EXT_IRQ semaphore\r\n");
			  portYIELD_FROM_ISR(reschedule);
		  }
	  }
	  PINS_DRV_ClearPortIntFlagCmd(PORTD);
}
void PTC_EXT_IRQ (void)
{
	  uint32_t buttonsPressed = PINS_DRV_GetPortIntFlag(PORTC) & ( ( 1 <<10 ) );  //��ȡ�жϱ�־λ״̬
	  BaseType_t reschedule;
	  //����ж�
	  if(buttonsPressed !=0 )
	  {
		  if( ((buttonsPressed >>10) & 0x01) == 1 )
		  {
			  xSemaphoreGiveFromISR(spi_m4_1_sem, &reschedule);
			  DEBUGprintf("\r\n[R]PTC10 m4_1 spi IRQ\r\n");
			  portYIELD_FROM_ISR(reschedule);
		  }
	  }
	  PINS_DRV_ClearPortIntFlagCmd(PORTC);
}

void PTB_EXT_IRQ (void)
{
	  uint32_t buttonsPressed = PINS_DRV_GetPortIntFlag(PORTB) & ( ( 1 <<5 ) );  //��ȡ�жϱ�־λ״̬
	  /*����ж�*/
	  if(buttonsPressed !=0 )
	  {
		  if( ((buttonsPressed >>5) & 0x01) == 1 )
		  {
			  PTB5_interrupt = 1;
		  }

	  }
	  PINS_DRV_ClearPortIntFlagCmd(PORTB);
}



void External_interrupt_Task( void *pvParameters )
{
	// Casting pvParameters to void because it is unused
	(void)pvParameters;
	External_interrupt_init();
	while(1)
	{

	}

}












