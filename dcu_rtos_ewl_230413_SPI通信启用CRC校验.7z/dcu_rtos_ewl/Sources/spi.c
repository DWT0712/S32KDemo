
#include "Cpu.h"
#include "console.h"
#include <stdio.h>
#include <string.h>
#include "flexcan.h"
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "flexcan.h"
#include "external_interrupt.h"

/* SDK includes. */
#include "interrupt_manager.h"
#include "clock_manager.h"
#include "clockMan1.h"
#include "pin_mux.h"

#include "tja115x.h"
#include "lpit_delay.h"

#include "spi.h"

#define SPI_RECEIVE_DATA_TASK_QUEUE   	3

extern QueueHandle_t xCanReceiveQueue;

QueueHandle_t xSpiReceiveQueue = NULL;

flexcan_msgbuff_t CAN_RxFIFO_RX_Message_Buffer1[1];/*circle buffer for CAN RxFIFO RX*/

extern SemaphoreHandle_t spi_m4_1_sem;

typedef struct
{
    uint8_t senddataByte[10];
    uint8_t receivedataByte[10];

} spi_state_t;
spi_state_t spi_DataBuffer;

//spi��ʼ��
//status_t ret;
void spi_init(void)
{

#if HW_EVT1_SPI2
	//spi2��ʼ��Ϊ����
	SPI_MasterInit(&spi2Instance,&spi2_MasterConfig0);

	INT_SYS_SetPriority(LPSPI2_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+2);

	INT_SYS_SetPriority(DMA3_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2);
	INT_SYS_SetPriority(DMA4_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2);
#endif
#if HW_EVT2_SPI0
	SPI_MasterInit(&spi0Instance,&spi0_MasterConfig0);
	INT_SYS_SetPriority(LPSPI0_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY+2);

	INT_SYS_SetPriority(DMA6_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2);
	INT_SYS_SetPriority(DMA7_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY + 2);
#endif
	//֡ͷ
	spi_DataBuffer.senddataByte[0]=0xaa;
	spi_DataBuffer.senddataByte[1]=0x55;
	//����֡���ȣ����ȷ�Χ����������+��дλ+���ݣ�
	spi_DataBuffer.senddataByte[2]=0x05;
	//�������ͣ�01��CAN���ݣ�02��Lin���ݣ�
	spi_DataBuffer.senddataByte[3]=0x01;
	//��дλ��01��ֻ����02��ֻд��03���ɶ���д��
	spi_DataBuffer.senddataByte[4]=0x3;
	//���� 0x64:message_ID��0x01:values_1,0x75��Zone_ID,
	spi_DataBuffer.senddataByte[5]=0x64;
	spi_DataBuffer.senddataByte[6]=0x01;
	spi_DataBuffer.senddataByte[7]=0x75;
	//CRCУ��ֵ
	crc16_calc((uint8_t *)&spi_DataBuffer.senddataByte[0], 8, CRC_CALCULATE);
//	ret = crc16_calc((uint8_t *)&spi_DataBuffer.senddataByte[0], 2, CRC_VERIFY);
//	ret = crc16_calc((uint8_t *)&spi_DataBuffer.senddataByte[0], 2, CRC_CALCULATE);
//	ret = crc16_calc((uint8_t *)&spi_DataBuffer.senddataByte[0], 2, CRC_VERIFY);

	xSpiReceiveQueue = xQueueCreate(SPI_RECEIVE_DATA_TASK_QUEUE, sizeof(spi_DataBuffer.receivedataByte));
	if(xSpiReceiveQueue == NULL)
	{
		DEBUGprintf("xSpiReceiveQueue create failed\r\n");
	}
	else
	{
		DEBUGprintf("xSpiReceiveQueue create success\r\n");
	}
}

void spi_send_data(void)
{

	//֡ͷ
	spi_DataBuffer.senddataByte[0]=0xaa;
	spi_DataBuffer.senddataByte[1]=0x55;
	//����֡���ȣ����ȷ�Χ����������+��дλ+���ݣ�
	spi_DataBuffer.senddataByte[2]=0x05;
	//�������ͣ�01��CAN���ݣ�02��Lin���ݣ�
	spi_DataBuffer.senddataByte[3]=0x01;
	//��дλ��01��ֻ����02��ֻд��03���ɶ���д��
	spi_DataBuffer.senddataByte[4]=0x3;
	//���� 0x64:message_ID��,0x01:values_1,0x75��Zone_ID
	spi_DataBuffer.senddataByte[5]=CAN_RxFIFO_RX_Message_Buffer1[0].msgId;
	spi_DataBuffer.senddataByte[6]=CAN_RxFIFO_RX_Message_Buffer1[0].data[0];
	spi_DataBuffer.senddataByte[7]=CAN_RxFIFO_RX_Message_Buffer1[0].data[1];
	//CRCУ��ֵ
	crc16_calc((uint8_t *)&spi_DataBuffer.senddataByte[0], 8, CRC_CALCULATE);

	DEBUGprintf("\r\n[T].M4_1 SPI data=[%2X:%2X:%2X:%2X:%2X:%2X:%2X:%2X:%2X:%2X] \r\n",spi_DataBuffer.senddataByte[0],spi_DataBuffer.senddataByte[1],spi_DataBuffer.senddataByte[2],spi_DataBuffer.senddataByte[3],spi_DataBuffer.senddataByte[4],\
																		  	  	  	  	  	spi_DataBuffer.senddataByte[5],spi_DataBuffer.senddataByte[6],spi_DataBuffer.senddataByte[7],spi_DataBuffer.senddataByte[8],spi_DataBuffer.senddataByte[9]);

#if HW_EVT1_SPI2
	SPI_MasterTransfer(&spi2Instance,spi_DataBuffer.senddataByte,NULL,10);
#endif
#if HW_EVT2_SPI0
	SPI_MasterTransfer(&spi0Instance,spi_DataBuffer.senddataByte,NULL,10);
#endif
}

void SpiSend_Task( void *pvParameters )
{
	(void)pvParameters;
	while(1)
	{
		if (xQueueReceive(xCanReceiveQueue, &CAN_RxFIFO_RX_Message_Buffer1[0], portMAX_DELAY))
		{
			spi_send_data();
		}
	}
}

#if 0
void spi_receive_data(void)
{
#if HW_EVT1_SPI2
	SPI_MasterTransferBlocking(&spi2Instance,NULL,spi_DataBuffer.receivedataByte,10,1);
#endif
#if HW_EVT2_SPI0
	SPI_MasterTransferBlocking(&spi0Instance,NULL,spi_DataBuffer.receivedataByte,10,1);
#endif

	if(xQueueSend( xSpiReceiveQueue, &spi_DataBuffer.receivedataByte[0], (TickType_t)0 ) != pdTRUE)
	{
		DEBUGprintf("xQueueSend send failed\r\n");
	}
}
#endif

//SPI��������
void SpiRecevive_Task( void *pvParameters )
{
	/* Casting pvParameters to void because it is unused */
	(void)pvParameters;

//	xSpiReceiveQueue = xQueueCreate(SPI_RECEIVE_DATA_TASK_QUEUE, sizeof(spi_DataBuffer.receivedataByte));
//	if(xSpiReceiveQueue == NULL)
//	{
//		DEBUGprintf("xSpiReceiveQueue create failed\r\n");
//	}
//	else
//	{
//		DEBUGprintf("xSpiReceiveQueue create success\r\n");
//	}
	for(;;)
	{
		/* Wait for transfer to finish */
		xSemaphoreTake(spi_m4_1_sem, portMAX_DELAY);
		OSIF_TimeDelay(1);
		//spi_receive_data();//spi��������
#if HW_EVT1_SPI2
		SPI_MasterTransferBlocking(&spi2Instance,NULL,spi_DataBuffer.receivedataByte,10,1);
#endif
#if HW_EVT2_SPI0
		SPI_MasterTransferBlocking(&spi0Instance,NULL,spi_DataBuffer.receivedataByte,10,10);
#endif
		//spi_DataBuffer.receivedataByte[8] = 0x70;spi_DataBuffer.receivedataByte[9] = 0x73;
		DEBUGprintf("[R].M4_1 SPI data=[%2X:%2X:%2X:%2X:%2X:%2X:%2X:%2X:%2X:%2X]\r\n",spi_DataBuffer.receivedataByte[0],spi_DataBuffer.receivedataByte[1],spi_DataBuffer.receivedataByte[2],spi_DataBuffer.receivedataByte[3],spi_DataBuffer.receivedataByte[4],\
																	  	  	  	  	  	  spi_DataBuffer.receivedataByte[5],spi_DataBuffer.receivedataByte[6],spi_DataBuffer.receivedataByte[7],spi_DataBuffer.receivedataByte[8],spi_DataBuffer.receivedataByte[9]);
		if((spi_DataBuffer.receivedataByte[0] == 0xAA)&&(spi_DataBuffer.receivedataByte[1] == 0x55))
		{
			if(RECV_CRC_VERIFY != CRC_VERIFY)
			{
				if(xQueueSend( xSpiReceiveQueue, &spi_DataBuffer.receivedataByte[0], (TickType_t)0 ) != pdTRUE)
				{
					DEBUGprintf("xQueueSend errQUEUE_FULL!\r\n");
				}
			}
			else
			{
				if( crc16_calc((uint8_t *)&spi_DataBuffer.receivedataByte[0], 8, CRC_VERIFY) == E_OK)
				{
					if(xQueueSend( xSpiReceiveQueue, &spi_DataBuffer.receivedataByte[0], (TickType_t)0 ) != pdTRUE)
					{
						DEBUGprintf("xQueueSend errQUEUE_FULL!\r\n");
					}
				}
				else
				{
					DEBUGprintf("spi Recevive Data CRC_ERROR!\r\n");
				}
			}
		}
	}
}


void slaveSpi_Callback(void *driverState, spi_event_t event, void *userData)
{
	(void)userData; //���ξ���
	(void)driverState;
	//status_t stat;

	//stat=SPI_GetStatus(&spi2Instance);//��ȡ����״̬ ������ճɹ���������æ

	if(event == SPI_EVENT_END_TRANSFER){  //�ӻ�������ɺ� ����ص�����


	  //�˴����������߼� �����ȡ���յ�������
		PINS_DRV_TogglePins(PTD, 1 << 16);
	}
}


uint8_t SPI_ReadWrite_Byte(uint8_t Tx_Buf)
{
	  uint8_t Rx_Buf[1] = {0};
	  SPI_MasterTransferBlocking(&spi2Instance,&Tx_Buf,&Rx_Buf,1,1000);
	  return Rx_Buf[0];
}


/*SPIд����ֽ�*/
uint8_t SPI1_Write_Buff(uint8_t reg,uint8_t *Tx_Buf,int lens)
{
	   uint8_t status;
	   int ctr;
	   status = SPI_ReadWrite_Byte(reg);
	   for(ctr=0; ctr<lens; ctr++)
		{
		   SPI_ReadWrite_Byte(Tx_Buf[ctr]); //д������
		}
		return status;
}
/*SPI������ֽ�*/
uint8_t SPI1_Read_Buff(uint8_t reg,uint8_t *Tx_Buf,int lens)
{
	   uint8_t status;
	   int ctr;
	   status = SPI_ReadWrite_Byte(reg);
	   for(ctr=0;ctr<lens;ctr++)
	   {
		   Tx_Buf[ctr]=SPI_ReadWrite_Byte(0XFF);
	   }
		return status;
}

//CRC16-16/MODBUS ����ʽ��0x8005; Seed=0xFFFF; XOROUT=0x0000; RefIN=bits RefOut=byte&bits
//calc_verify: CRC_CALCULATE; CRC_VERIFY
//result:���ģʽ��� [n]=���ֽ�;[n+1]=���ֽ�
//Sample1��[0xAA][0x55] [0x2F][0xBF]  result = 0x2fbf
//Sample2��[0xAA][0x55][0x05][0x01][0x03][0x64][0x01][0x75] [0x70][0x73]  result = 0x7073
uint8_t crc16_calc(uint8_t *data, uint32_t crc_len, uint8_t calc_verify)
{
	uint32_t result;
	uint8_t	crc_result[2];
	uint8_t crc_val[2];
	status_t status = E_NOT_OK;

	crc_val[0] = *(data + crc_len);
	crc_val[1] = *(data + crc_len + 1);

	CRC_DRV_WriteData(INST_CRC1,(const uint8_t*)data,crc_len);
	result = CRC_DRV_GetCrcResult(INST_CRC1);
	CRC_DRV_Configure(INST_CRC1, &crc1_InitConfig0);

	crc_result[1] = result & 0xFF;
	crc_result[0] = (result >> 8) & 0xFF;
	if(calc_verify == CRC_CALCULATE) 	//calc
	{
		*(data + crc_len) = crc_result[0];
		*(data + crc_len + 1) = crc_result[1];
		status = E_OK;
	}
	else //VERIFY
	{
		if((crc_val[0] == crc_result[0]) && (crc_val[1] == crc_result[1]))
		{
			status = E_OK;
		}
		else
		{
			status = E_NOT_OK;
		}
	}
	return(status);
}
