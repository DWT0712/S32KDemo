/*
 * lpit_delay.c
 *
 *  Created on: 2023��3��4��
 *      Author: yish
 */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/* SDK includes. */
#include "interrupt_manager.h"
#include "clock_manager.h"
#include "clockMan1.h"
#include "pin_mux.h"

#include <string.h>
#include <stdio.h>

#include "lpit_delay.h"

/*! @brief Converts milliseconds to ticks - in this case, one tick = one millisecond */
#define MSEC_TO_TICK(msec) (msec)

static volatile uint32_t s_snail_tick_cnt = 0u;

static inline void snail_Tick(void)
{
	s_snail_tick_cnt++;
}

static inline uint32_t GetCurrentTickCount(void)
{
    return s_snail_tick_cnt;
}

static inline void updateTickConfig(void)
{
	s_snail_tick_cnt = 0;

	/* Start LPIT0 channel 0 counter */
	LPIT_DRV_StartTimerChannels(INST_LPIT1, (1 << 0));

}
static inline void closeTickConfig(void)
{
	LPIT_DRV_StopTimerChannels(INST_LPIT1, (1 << 0));
}
void s_TimeDelay(const uint32_t delay)
{
	updateTickConfig();

    uint32_t start = GetCurrentTickCount();
    uint32_t crt_ticks = GetCurrentTickCount();
    uint32_t delta = crt_ticks - start;
    uint32_t delay_ticks = MSEC_TO_TICK(delay);
    while (delta < delay_ticks)
    {
        crt_ticks = GetCurrentTickCount();
        delta = crt_ticks - start;
    }
    closeTickConfig();
}

void lpit_ch0_isr(void)
{
	LPIT_DRV_ClearInterruptFlagTimerChannels(INST_LPIT1, (1 << 0));
	snail_Tick();

//	PINS_DRV_TogglePins(PTA, 1 << 13);
}
void lpit_init(void)
{
	LPIT_DRV_Init(INST_LPIT1, &lpit1_InitConfig);
	LPIT_DRV_InitChannel(INST_LPIT1, 0, &lpit1_ChnConfig0);
	INT_SYS_InstallHandler(LPIT0_Ch0_IRQn, &lpit_ch0_isr, (isr_t *)0);

	/* Start LPIT0 channel 0 counter */
//	LPIT_DRV_StartTimerChannels(INST_LPIT1, (1 << 0));
}


