#ifndef EXTERNAL_INTERRUPT_H
#define EXTERNAL_INTERRUPT_H

void External_interrupt_init(void);
void PTD_EXT_IRQ (void);
void PTB_EXT_IRQ (void);
void PTC_EXT_IRQ (void);
void External_interrupt_Task( void *pvParameters );
#endif
