/*
 * lpit_delay.h
 *
 *  Created on: 2023��3��4��
 *      Author: yish
 */

#ifndef LPIT_DELAY_H_
#define LPIT_DELAY_H_

#define	NXP_OSIF		0
#define SNAIL_OSIF		1
#define DELAY_TYPE		SNAIL_OSIF

void lpit_ch0_isr(void);
void lpit_init(void);
void s_TimeDelay(const uint32_t delay);

#endif /* LPIT_DELAY_H_ */
