/* 
 * Copyright (c) 2015 - 2016 , Freescale Semiconductor, Inc.                             
 * Copyright 2016-2017 NXP                                                                    
 * All rights reserved.                                                                  
 *                                                                                       
 * THIS SOFTWARE IS PROVIDED BY NXP "AS IS" AND ANY EXPRESSED OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL NXP OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING
 * IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.                          
 */

/*
 * main-blinky.c is included when the "Blinky" build configuration is used.
 * main-full.c is included when the "Full" build configuration is used.
 *
 * main-blinky.c (this file) defines a very simple demo that creates two tasks,
 * one queue, and one timer.  It also demonstrates how Cortex-M4 interrupts can
 * interact with FreeRTOS tasks/timers.
 *
 * This simple demo project runs 'stand alone' (without the rest of the tower
 * system) on the Freedom Board or Validation Board, which is populated with a
 * S32K144 Cortex-M4 microcontroller.
 *
 * The idle hook function:
 * The idle hook function demonstrates how to query the amount of FreeRTOS heap
 * space that is remaining (see vApplicationIdleHook() defined in this file).
 *
 * The main() Function:
 * main() creates one software timer, one queue, and two tasks.  It then starts
 * the scheduler.
 *
 * The Queue Send Task:
 * The queue send task is implemented by the prvQueueSendTask() function in
 * this file.  prvQueueSendTask() sits in a loop that causes it to repeatedly
 * block for 200 milliseconds, before sending the value 100 to the queue that
 * was created within main().  Once the value is sent, the task loops back
 * around to block for another 200 milliseconds.
 *
 * The Queue Receive Task:
 * The queue receive task is implemented by the prvQueueReceiveTask() function
 * in this file.  prvQueueReceiveTask() sits in a loop that causes it to
 * repeatedly attempt to read data from the queue that was created within
 * main().  When data is received, the task checks the value of the data, and
 * if the value equals the expected 100, toggles the green LED.  The 'block
 * time' parameter passed to the queue receive function specifies that the task
 * should be held in the Blocked state indefinitely to wait for data to be
 * available on the queue.  The queue receive task will only leave the Blocked
 * state when the queue send task writes to the queue.  As the queue send task
 * writes to the queue every 200 milliseconds, the queue receive task leaves the
 * Blocked state every 200 milliseconds, and therefore toggles the blue LED
 * every 200 milliseconds.
 *
 * The LED Software Timer and the Button Interrupt:
 * The user button BTN1 is configured to generate an interrupt each time it is
 * pressed.  The interrupt service routine switches the red LED on, and
 * resets the LED software timer.  The LED timer has a 5000 millisecond (5
 * second) period, and uses a callback function that is defined to just turn the
 * LED off again.  Therefore, pressing the user button will turn the LED on, and
 * the LED will remain on until a full five seconds pass without the button
 * being pressed.
 */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"

/* SDK includes. */
#include "interrupt_manager.h"
#include "clock_manager.h"
#include "clockMan1.h"
#include "pin_mux.h"

#include "BoardDefines.h"
#include <string.h>
#include <stdio.h>

#include "mainConfig.h"
#include "console.h"
#include "MemMon.h"
#include "tja115x.h"
#include "lpit_delay.h"
#include "flexcan.h"
#include "spi.h"
#include "external_interrupt.h"
#include "adc.h"
#include "Flash1.h"
/* Priorities at which the tasks are created. */
#define mainCAN_SEND_TASK_PRIORITY			( tskIDLE_PRIORITY + 3 )
#define mainQUEUE_RECEIVE_TASK_PRIORITY		( tskIDLE_PRIORITY + 2 )
#define	mainQUEUE_SEND_TASK_PRIORITY		( tskIDLE_PRIORITY + 1 )


/* The rate at which data is sent to the queue, specified in milliseconds, and
converted to ticks using the portTICK_PERIOD_MS constant. */
#define mainQUEUE_SEND_FREQUENCY_MS			( 400 / portTICK_PERIOD_MS )

/* The LED will remain on until the button has not been pushed for a full
5000ms. */
#define mainBUTTON_LED_TIMER_PERIOD_MS		( 5000UL / portTICK_PERIOD_MS )

/* The number of items the queue can hold.  This is 1 as the receive task
will remove items as they are added, meaning the send task should always find
the queue empty. */
#define mainQUEUE_LENGTH					( 1 )

/* The LED toggle by the queue receive task (blue). */
#define mainTASK_CONTROLLED_LED				( 1UL << 0UL )

/* The LED turned on by the button interrupt, and turned off by the LED timer
(green). */
#define mainTIMER_CONTROLLED_LED			( 1UL << 1UL )

/* The vector used by the GPIO port C.  Button SW7 is configured to generate
an interrupt on this port. */
#define mainGPIO_C_VECTOR					( 61 )

/* A block time of zero simply means "don't block". */
#define mainDONT_BLOCK						( 0UL )

/*-----------------------------------------------------------*/
#define MAX_MESSAGE_SIZE					( 256 )

/* Task 1 counter */
volatile unsigned long task1_counter;
/* Task 2 counter */
volatile unsigned long task2_counter;
/* idle task counter */
volatile unsigned long idle_counter;
/* Command mode message buffer */
static char msg[MAX_MESSAGE_SIZE];

//EEPROM��ض���
/* Declare a FLASH config struct which initialized by FlashInit, and will be used by all flash operations */
flash_ssd_config_t flashSSDConfig;
/* Data source for program operation */
#define BUFFER_SIZE         0x100u          /* Size of data source */
uint8_t sourceBuffer[BUFFER_SIZE];
uint8_t bufa[6] = {0x11,0x12,0x13,0x14,0x15,0x16};
uint8_t bufb[7] = {0x21,0x22,0x23,0x24,0x25,0x26,0x27};


static void User_Init( void );

/*
 * Setup the NVIC, LED outputs, and button inputs.
 */
static void prvSetupHardware( void );

/*
 * The tasks as described in the comments at the top of this file.
 */
//static void prvQueueReceiveTask( void *pvParameters );
//static void prvQueueSendTask( void *pvParameters );
//static void External_interrupt_Task( void *pvParameters );
//static void Adc_Task( void *pvParameters );
/*
 * The LED timer callback function.  This does nothing but switch off the
 * LED defined by the mainTIMER_CONTROLLED_LED constant.
 */
static void prvButtonLEDTimerCallback( TimerHandle_t xTimer );

/*-----------------------------------------------------------*/

/* The queue used by both tasks. */
static QueueHandle_t xQueue = NULL;

/* The LED software timer.  This uses prvButtonLEDTimerCallback() as its callback
function. */

/* free heap memory get from idle task */
volatile size_t xFreeHeapSpace;

static TimerHandle_t xButtonLEDTimer = NULL;

/*-----------------------------------------------------------*/

void rtos_start( void )
{
	/* Configure the NVIC, LED outputs and button inputs. */
	prvSetupHardware();

	/* Create the queue. */
	xQueue = xQueueCreate( mainQUEUE_LENGTH, sizeof( unsigned long ) );

	if( xQueue != NULL )
	{
		/* Start the two tasks as described in the comments at the top of this
		file. */
#if HW_EVT1
		xTaskCreate( TJA115xTask, "TJA115xTask", 512, NULL, mainCAN_SEND_TASK_PRIORITY, NULL );
#endif
#if HW_EVT2
		xTaskCreate( CAN0_Send_Task, "CAN0_Send_Task", 512, NULL, 3, NULL );
#endif

		xTaskCreate( ReceiveCan_SendSpiTask, "ReceiveCan_SendSpiTask", 512, NULL, 2, NULL );
		//xTaskCreate( prvQueueReceiveTask, "RX", 512, NULL, mainQUEUE_RECEIVE_TASK_PRIORITY, NULL );

		//xTaskCreate( prvQueueSendTask, "TX", 512, NULL, mainQUEUE_SEND_TASK_PRIORITY, NULL );

		xTaskCreate( SpiRecevive_Task, "SpiReceive_Task", 512, NULL, 2, NULL );

		xTaskCreate( SpiSend_Task, "SpiSend_Task", 512, NULL, 3, NULL );


		//xTaskCreate( Adc_Task, "adc_task", 512, NULL, 2, NULL );

		//xTaskCreate( External_interrupt_Task, "External_interrupt_task", 512, NULL, 2, NULL );


		/* Create the software timer that is responsible for turning off the LED
		if the button is not pushed within 5000ms, as described at the top of
		this file. */
		xButtonLEDTimer = xTimerCreate( "ButtonLEDTimer", 			/* A text name, purely to help debugging. */
									mainBUTTON_LED_TIMER_PERIOD_MS,	/* The timer period, in this case 5000ms (5s). */
									pdFALSE,						/* This is a one shot timer, so xAutoReload is set to pdFALSE. */
									( void * ) 0,					/* The ID is not used, so can be set to anything. */
									prvButtonLEDTimerCallback		/* The callback function that switches the LED off. */
								);

		/* Start the tasks and timer running. */
		vTaskStartScheduler();
	}

	/* If all is well, the scheduler will now be running, and the following line
	will never be reached.  If the following line does execute, then there was
	insufficient FreeRTOS heap memory available for the idle and/or timer tasks
	to be created.  See the memory management section on the FreeRTOS web site
	for more details. */
	for( ;; );
}
/*-----------------------------------------------------------*/

static void prvButtonLEDTimerCallback( TimerHandle_t xTimer )
{
	/* Casting xTimer to void because it is unused */
	(void)xTimer;

	/* The timer has expired - so no button pushes have occurred in the last
	five seconds - turn the LED off. */
//	PINS_DRV_SetPins(LED_GPIO, (1 << LED1));
}
/*-----------------------------------------------------------*/

/* The ISR executed when the user button is pushed. */
void vPort_C_ISRHandler( void )
{
    portBASE_TYPE xHigherPriorityTaskWoken = pdFALSE;
    int CommandMode=1;

	/* The button was pushed, so ensure the LED is on before resetting the
	LED timer.  The LED timer will turn the LED off if the button is not
	pushed within 5000ms. */
//    PINS_DRV_ClearPins(LED_GPIO, (1 << LED1));
	/* This interrupt safe FreeRTOS function can be called from this interrupt
	because the interrupt priority is below the
	configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY setting in FreeRTOSConfig.h. */
	xTimerResetFromISR( xButtonLEDTimer, &xHigherPriorityTaskWoken );

	DEBUGprintf("\nCommand mode\n============\n");
	DEBUGprintf("%s\nReady\n",helpMsg);

	while (CommandMode)
	{
		scanf("%s",msg);
		if (strlen(msg)>1)
			DEBUGprintf("Unknown command %s\n\n\rReady\n\r",msg);
		else
			CommandMode=ProcessMessage(msg[0]);
	}
	
	/* Clear the interrupt before leaving. */
	PINS_DRV_ClearPortIntFlagCmd(BTN_PORT);

	/* If calling xTimerResetFromISR() caused a task (in this case the timer
	service/daemon task) to unblock, and the unblocked task has a priority
	higher than or equal to the task that was interrupted, then
	xHigherPriorityTaskWoken will now be set to pdTRUE, and calling
	portEND_SWITCHING_ISR() will ensure the unblocked task runs next. */
	portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}
/*-----------------------------------------------------------*/
#if 0
static void prvQueueSendTask( void *pvParameters )
{
TickType_t xNextWakeTime;
const unsigned long ulValueToSend = 100UL;

	/* Casting pvParameters to void because it is unused */
	(void)pvParameters;

	/* Initialise xNextWakeTime - this only needs to be done once. */
	xNextWakeTime = xTaskGetTickCount();

	for( ;; )
	{
		/* Place this task in the blocked state until it is time to run again.
		The block time is specified in ticks, the constant used converts ticks
		to ms.  While in the Blocked state this task will not consume any CPU
		time. */
		DEBUGprintf("Task 1 counter: 0x%.8X\r\n",(int)task1_counter++);
		vTaskDelayUntil( &xNextWakeTime, mainQUEUE_SEND_FREQUENCY_MS );

		/* Send to the queue - causing the queue receive task to unblock and
		toggle an LED.  0 is used as the block time so the sending operation
		will not block - it shouldn't need to block as the queue should always
		be empty at this point in the code. */
		xQueueSend( xQueue, &ulValueToSend, mainDONT_BLOCK );
	}
}
/*-----------------------------------------------------------*/

static void prvQueueReceiveTask( void *pvParameters )
{
unsigned long ulReceivedValue;

	/* Casting pvParameters to void because it is unused */
	(void)pvParameters;

	for( ;; )
	{
		/* Wait until something arrives in the queue - this task will block
		indefinitely provided INCLUDE_vTaskSuspend is set to 1 in
		FreeRTOSConfig.h. */
		xQueueReceive( xQueue, &ulReceivedValue, portMAX_DELAY );

		/*  To get here something must have been received from the queue, but
		is it the expected value?  If it is, toggle the LED. */
		if( ulReceivedValue == 100UL )
		{
			if (task1_counter % 2 == 0)
			{
				task2_counter++;
				DEBUGprintf("Task 2 counter: 0x%.8X\r\n",(int)task2_counter);
			}
//		    PINS_DRV_TogglePins(LED_GPIO, (1 << LED2));
		}
	}
}
#endif
/*-----------------------------------------------------------*/

static void prvSetupHardware( void )
{

    /* Initialize and configure clocks
     *  -   Setup system clocks, dividers
     *  -   see clock manager component for more details
     */
    CLOCK_SYS_Init(g_clockManConfigsArr, CLOCK_MANAGER_CONFIG_CNT,
                   g_clockManCallbacksArr, CLOCK_MANAGER_CALLBACK_CNT);
    CLOCK_SYS_UpdateConfiguration(0U, CLOCK_MANAGER_POLICY_AGREEMENT);
#if 0
    boardSetup();	//����PTA13ΪBTN,����PTA13��pin_mux������Ϊ���������PIT

	/* Change LED1, LED2 to outputs. */
//	PINS_DRV_SetPinsDirection(LED_GPIO,  (1 << LED1) | (1 << LED2));

	/* Change BTN1 to input */
	PINS_DRV_SetPinsDirection(BTN_GPIO, ~(1 << BTN_PIN));

	/* Start with LEDs off. */
//	PINS_DRV_SetPins(LED_GPIO, (1 << LED1) | (1 << LED2));

	/* Install Button interrupt handler */
    INT_SYS_InstallHandler(BTN_PORT_IRQn, vPort_C_ISRHandler, (isr_t *)NULL);
    /* Enable Button interrupt handler */
    INT_SYS_EnableIRQ(BTN_PORT_IRQn);

    /* The interrupt calls an interrupt safe API function - so its priority must
    be equal to or lower than configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY. */
    INT_SYS_SetPriority( BTN_PORT_IRQn, configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY );
#endif
    User_Init();
}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
	/* Called if a call to pvPortMalloc() fails because there is insufficient
	free memory available in the FreeRTOS heap.  pvPortMalloc() is called
	internally by FreeRTOS API functions that create tasks, queues, software
	timers, and semaphores.  The size of the FreeRTOS heap is set by the
	configTOTAL_HEAP_SIZE configuration constant in FreeRTOSConfig.h. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( TaskHandle_t pxTask, char *pcTaskName )
{
	( void ) pcTaskName;
	( void ) pxTask;

	/* Run time stack overflow checking is performed if
	configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
	function is called if a stack overflow is detected. */
	taskDISABLE_INTERRUPTS();
	for( ;; );
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
//    volatile size_t xFreeHeapSpace;

	/* This function is called on each cycle of the idle task.  In this case it
	does nothing useful, other than report the amount of FreeRTOS heap that
	remains unallocated. */
	xFreeHeapSpace = xPortGetFreeHeapSize();
	/* idle_counter may be used for monitoring CPU usage
	(ratio between Idle and task counters) */
	idle_counter++;

	if( xFreeHeapSpace > 100 )
	{
		/* By now, the kernel has allocated everything it is going to, so
		if there is a lot of heap remaining unallocated then
		the value of configTOTAL_HEAP_SIZE in FreeRTOSConfig.h can be
		reduced accordingly. */
	}

}
/*-----------------------------------------------------------*/

/* The Blinky build configuration does not include run time stats gathering,
however, the Full and Blinky build configurations share a FreeRTOSConfig.h
file.  Therefore, dummy run time stats functions need to be defined to keep the
linker happy. */
void vMainConfigureTimerForRunTimeStats( void ) {}
unsigned long ulMainGetRunTimeCounterValue( void ) { return 0UL; }

/* A tick hook is used by the "Full" build configuration.  The Full and blinky
build configurations share a FreeRTOSConfig.h header file, so this simple build
configuration also has to define a tick hook - even though it does not actually
use it for anything. */
void vApplicationTickHook( void ) {}

/*-----------------------------------------------------------*/
//user code
#define portNVIC_SYSTICK_CTRL_REG			( * ( ( volatile uint32_t * ) 0xe000e010 ) )
#define portNVIC_SYSTICK_LOAD_REG			( * ( ( volatile uint32_t * ) 0xe000e014 ) )
#define portNVIC_SYSTICK_CURRENT_VALUE_REG	( * ( ( volatile uint32_t * ) 0xe000e018 ) )
#define portNVIC_SYSPRI2_REG				( * ( ( volatile uint32_t * ) 0xe000ed20 ) )
/* ...then bits in the registers. */
#define portNVIC_SYSTICK_INT_BIT			( 1UL << 1UL )
#define portNVIC_SYSTICK_ENABLE_BIT			( 1UL << 0UL )
#define portNVIC_SYSTICK_COUNT_FLAG_BIT		( 1UL << 16UL )
#define portNVIC_PENDSVCLEAR_BIT 			( 1UL << 27UL )
#define portNVIC_PEND_SYSTICK_CLEAR_BIT		( 1UL << 25UL )

//#define configSYSTICK_CLOCK_HZ configCPU_CLOCK_HZ
#define portNVIC_SYSTICK_CLK_BIT	( 1UL << 2UL )

uint32_t core_freq;
sys_clk_config_t clk_source;

void vPortSetupTimerInterrupt( void )
{
	/* Calculate the constants required to configure the tick interrupt. */
	#if( configUSE_TICKLESS_IDLE == 1 )
	{
		ulTimerCountsForOneTick = ( configSYSTICK_CLOCK_HZ / configTICK_RATE_HZ );
		xMaximumPossibleSuppressedTicks = portMAX_24_BIT_NUMBER / ulTimerCountsForOneTick;
		ulStoppedTimerCompensation = portMISSED_COUNTS_FACTOR / ( configCPU_CLOCK_HZ / configSYSTICK_CLOCK_HZ );
	}
	#endif /* configUSE_TICKLESS_IDLE */

	/* Stop and clear the SysTick. */
	portNVIC_SYSTICK_CTRL_REG = 0UL;
	portNVIC_SYSTICK_CURRENT_VALUE_REG = 0UL;

	(void)CLOCK_DRV_GetFreq(CORE_CLOCK,&core_freq);
	(void)CLOCK_DRV_GetSystemClockSource(&clk_source);
	/* Configure SysTick to interrupt at the requested rate. */
	portNVIC_SYSTICK_LOAD_REG = ( core_freq / configTICK_RATE_HZ ) - 1UL;
	portNVIC_SYSTICK_CTRL_REG = ( portNVIC_SYSTICK_CLK_BIT | portNVIC_SYSTICK_INT_BIT | portNVIC_SYSTICK_ENABLE_BIT );

	DEBUGprintf("\r\n:::RTOS.core_freq = %d; source clk = %d \r\n\n",core_freq,clk_source.src);
}

Std_ReturnType tja115x_init_status;
static void User_Init( void )
{
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);

	CRC_DRV_Init(INST_CRC1, &crc1_InitConfig0);

	EDMA_DRV_Init(&dmaController1_State, &dmaController1_InitConfig0, edmaChnStateArray, edmaChnConfigArray, EDMA_CONFIGURED_CHANNELS_COUNT);

	if(DEBUG_MODE == DEBUG_UART_printf)
	{
		UART_Init(&uart_pal1_instance, &uart_pal1_Config0);
		DEBUGprintf("\r\n[0].UART_Init OK! \n");
	}
	else
	{
		DEBUGprintf("\r\n[0].Use RTT View! \n");
	}

	//==========================================================
	//EEPROM���
	/* Write your local variable definition here */
	status_t ret;        /* Store the driver APIs return code */
//	uint32_t address;
//	uint32_t size;
	uint32_t i;
    /* Init source data */
    for (i = 0u; i < BUFFER_SIZE; i++)
    {
        sourceBuffer[i] = i;
    }

    /* Always initialize the driver before calling other functions */
	ret = FLASH_DRV_Init(&Flash1_InitConfig0, &flashSSDConfig);
	DEV_ASSERT(STATUS_SUCCESS == ret);

	if (flashSSDConfig.EEESize == 0u)
	{
		/* Configure FlexRAM as EEPROM and FlexNVM as EEPROM backup region,
		         * DEFlashPartition will be failed if the IFR region isn't blank.
		         * Refer to the device document for valid EEPROM Data Size Code
		         * and FlexNVM Partition Code. For example on S32K144:
		         * - EEEDataSizeCode = 0x02u: EEPROM size = 4 Kbytes
		         * - DEPartitionCode = 0x08u: EEPROM backup size = 64 Kbytes
				 * - DEPartitionCode = 0x0au: EEPROM backup size = 48 Kbytes/16Kbytes bootloader */
		ret = FLASH_DRV_DEFlashPartition(&flashSSDConfig, 0x02u, 0x0au, 0x0u, false, true);
		DEV_ASSERT(STATUS_SUCCESS == ret);

		/* Re-initialize the driver to update the new EEPROM configuration */
		ret = FLASH_DRV_Init(&Flash1_InitConfig0, &flashSSDConfig);
		DEV_ASSERT(STATUS_SUCCESS == ret);

		/* Make FlexRAM available for EEPROM */
		ret = FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_ENABLE, 0x00u, NULL);
		DEV_ASSERT(STATUS_SUCCESS == ret);
		DEBUGprintf("\r\n[1].First EEE_Init OK! \n");
	}
	else    /* FLexRAM is already configured as EEPROM */
	{
		/* Make FlexRAM available for EEPROM, make sure that FlexNVM and FlexRAM
		 * are already partitioned successfully before */
		ret = FLASH_DRV_SetFlexRamFunction(&flashSSDConfig, EEE_ENABLE, 0x00u, NULL);
		DEV_ASSERT(STATUS_SUCCESS == ret);
	}
	 /* Try to write data to EEPROM if FlexRAM is configured as EEPROM */
	if (flashSSDConfig.EEESize != 0u)
	{
		DEBUGprintf("\r\n[1].EEE_Init OK! \n");
		DEBUGprintf("\r\n[1].EEE val=%8x \n",*((uint32_t *)( flashSSDConfig.EERAMBase + 4)));
#if 0
		address = flashSSDConfig.EERAMBase;
		size = sizeof(uint32_t);
		ret = FLASH_DRV_EEEWrite(&flashSSDConfig, address, size, sourceBuffer);
		DEV_ASSERT(STATUS_SUCCESS == ret);

		/* Try to update one byte in an EEPROM address which isn't aligned */
		address = flashSSDConfig.EERAMBase + 1u;
		size = sizeof(uint8_t);
		sourceBuffer[0u] = 0xFFu;
		ret = FLASH_DRV_EEEWrite(&flashSSDConfig, address, size, sourceBuffer);
		DEV_ASSERT(STATUS_SUCCESS == ret);

		address = flashSSDConfig.EERAMBase + 4u;
		size = sizeof(bufa);
		ret = FLASH_DRV_EEEWrite(&flashSSDConfig, address, size, bufa);
		DEV_ASSERT(STATUS_SUCCESS == ret);

		address = flashSSDConfig.EERAMBase + 10u;
		size = sizeof(bufb);
		ret = FLASH_DRV_EEEWrite(&flashSSDConfig, address, size, bufb);
		DEV_ASSERT(STATUS_SUCCESS == ret);
#endif
	}
    //==========================================================

	spi_init();

	//Adc_Init();

	External_interrupt_init();
//	INT_SYS_SetPriority(LPUART1_RxTx_IRQn,configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY);

//    FLEXCAN_DRV_Init(INST_FLEXCAN_CONFIG_2, &flexcanState1, &flexcanInitConfig1);
	CAN_User_Init();

	DEBUGprintf("\r\n[2].CAN0 Init OK! \n");

    lpit_init();

#if USE_TJA1153
	tja115x_init_status = tja115x_main();
	if(tja115x_init_status == STATUS_SUCCESS)
	{
		DEBUGprintf("\r\n[3].TJA1153 Init OK! \n");
	}
	else
	{
		DEBUGprintf("\r\n[4].TJA1153 Init FAIL:%d \n",tja115x_init_status);
	}
#endif
}

/*-----------------------------------------------------------*/
