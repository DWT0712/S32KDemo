/*
 * mainConfig.h
 *
 *  Created on: 2023��4��3��
 *      Author: yish
 */

#ifndef MAINCONFIG_H_
#define MAINCONFIG_H_

#define USE_TJA1153		0
#define USE_TJA1043		1
#define	HW_EVT1			USE_TJA1153
#define HW_EVT2			USE_TJA1043




#endif /* MAINCONFIG_H_ */
