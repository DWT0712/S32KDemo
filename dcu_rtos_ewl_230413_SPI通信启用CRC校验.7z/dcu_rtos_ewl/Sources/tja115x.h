/*
 * project.h
 *
 *  Created on: Aug 26, 2021
 *      Author: nxp74140
 */

#ifndef TJA115X_H_
#define TJA115X_H_

#include "Cpu.h"

/* Required aliases to share common code between projects configured
 * with ProcessorExpert (SDK3) and ConfigurationTool (SDK4).
 */
#define	sbcInitConfig0				sbc_uja116x1_InitConfig0
#define	INST_FLEXCAN_CONFIG_1		INST_CANCOM1
#define	INST_FLEXCAN_CONFIG_2		INST_CANCOM2
#define	flexcanState0				canCom1_State
#define	flexcanState1				canCom2_State
#define	flexcanInitConfig0			canCom1_InitConfig0
#define	flexcanInitConfig1			canCom2_InitConfig0
#define	INST_LPSPI_1				LPSPICOM1
#define	lpspi_1State				lpspiCom1State
#define	lpspi_0_MasterConfig0		lpspiCom1_MasterConfig0
#define INST_LPIT_CONFIG_1          INST_LPIT1
#define	trcv_tja115x_1_ConfigPtr	canTrcv1_ConfigPtr
#define	trcv_tja115x_1_CANConfig0	canTrcv1_CANConfig0
#define	trcv_tja115x_1_CANConfig1	canTrcv1_CANConfig1
#define	trcv_tja115x_1_DevCfgCmds0	canTrcv1_DevCfgCmds0
#define	trcv_tja115x_1_DevCfgCmds1	canTrcv1_DevCfgCmds1

// FOR DEBUG CONFIGURATION TEST
#define AFTER_INIT_SEND_TEST_DATA	1
#define TJA115X_TIMING	1		//����TJA1153ʱ��

Std_ReturnType 	tja115x_main(void);


#endif /* TJA115X_H_ */
