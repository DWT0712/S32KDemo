/* ###################################################################
**     Filename    : s32k14x_syslib.h
**
** ###################################################################*/

/* Include inherited beans */
#include "Cpu.h"

#define D_PRINTF			1
#define D_SPRINTF			2
#define D_BX_LR				3
#define D_GET_STACKFRAME	4	//ref . cypress

#define DEBUG_MODE 			D_BX_LR

typedef struct
{
	/** MemManage Fault Status Sub-register - MMFSR */
	uint32_t iaccViol    : 1;  /**< MemManage Fault - The instruction access violation flag */
	uint32_t daccViol    : 1;  /**< MemManage Fault - The data access violation flag */
	uint32_t reserved1   : 1;  /**< Reserved */
	uint32_t mUnstkErr   : 1;  /**< MemManage Fault - Unstacking for a return from exception */
	uint32_t mStkErr     : 1;  /**< MemManage Fault - MemManage fault on stacking for exception entry */
	uint32_t mlspErr     : 1;  /**< MemManage Fault - MemManage fault occurred during floating-point lazy state preservation */
	uint32_t reserved2   : 1;  /**< Reserved */
	uint32_t mmarValid   : 1;  /**< MemManage Fault - The MemManage Address register valid flag */
	/** Bus Fault Status Sub-register - UFSR */
	uint32_t iBusErr     : 1;  /**< Bus Fault - The instruction bus error */
	uint32_t precisErr   : 1;  /**< Bus Fault - The precise Data bus error */
	uint32_t imprecisErr : 1;  /**< Bus Fault - The imprecise data bus error */
	uint32_t unstkErr    : 1;  /**< Bus Fault - Unstacking for an exception return has caused one or more bus faults */
	uint32_t stkErr      : 1;  /**< Bus Fault - Stacking for an exception entry has caused one or more bus faults */
	uint32_t lspErr      : 1;  /**< Bus Fault - A bus fault occurred during the floating-point lazy state */
	uint32_t reserved3   : 1;  /**< Reserved */
	uint32_t bfarValid   : 1;  /**< Bus Fault - The bus fault address register valid flag */
	/** Usage Fault Status Sub-register - UFSR */
	uint32_t undefInstr  : 1;  /**< Usage Fault - An undefined instruction */
	uint32_t invState    : 1;  /**< Usage Fault - The invalid state */
	uint32_t invPC       : 1;  /**< Usage Fault - An invalid PC */
	uint32_t noCP        : 1;  /**< Usage Fault - No coprocessor */
	uint32_t reserved4   : 4;  /**< Reserved */
	uint32_t unaligned   : 1;  /**< Usage Fault - Unaligned access */
	uint32_t divByZero   : 1;  /**< Usage Fault - Divide by zero */
	uint32_t reserved5   : 6;  /**< Reserved */
} stc_fault_cfsr_t;

/** Hard Fault Status Register - HFSR */
typedef struct
{
	uint32_t reserved1   :  1;   /**< Reserved. */
	uint32_t vectTbl     :  1;   /**< HFSR - Indicates a bus fault on a vector table read during exception processing */
	uint32_t reserved2   : 28;   /**< Reserved. */
	uint32_t forced      :  1;   /**< HFSR - Indicates a forced hard fault */
	uint32_t debugEvt    :  1;   /**< HFSR - Reserved for the debug use.  */
} stc_fault_hfsr_t;

/** System Handler Control and State Register - SHCSR */
typedef struct
{
	uint32_t memFaultAct    :  1;   /**< SHCSR - The MemManage exception active bit, reads as 1 if the exception is active */
	uint32_t busFaultAct    :  1;   /**< SHCSR - The BusFault exception active bit, reads as 1 if the exception is active */
	uint32_t reserved1      :  1;   /**< Reserved. */
	uint32_t usgFaultAct    :  1;   /**< SHCSR - The UsageFault exception active bit, reads as 1 if the exception is active */
	uint32_t reserved2      :  3;   /**< Reserved. */
	uint32_t svCallAct      :  1;   /**< SHCSR - The SVCall active bit, reads as 1 if the SVC call is active */
	uint32_t monitorAct     :  1;   /**< SHCSR - The debug monitor active bit, reads as 1 if the debug monitor is active */
	uint32_t reserved3      :  1;   /**< Reserved. */
	uint32_t pendSVAct      :  1;   /**< SHCSR - The PendSV exception active bit, reads as 1 if the exception is active */
	uint32_t sysTickAct     :  1;   /**< SHCSR - The SysTick exception active bit, reads as 1 if the exception is active  */
	uint32_t usgFaultPended :  1;   /**< SHCSR - The UsageFault exception pending bit, reads as 1 if the exception is pending */
	uint32_t memFaultPended :  1;   /**< SHCSR - The MemManage exception pending bit, reads as 1 if the exception is pending */
	uint32_t busFaultPended :  1;   /**< SHCSR - The BusFault exception pending bit, reads as 1 if the exception is pending */
	uint32_t svCallPended   :  1;   /**< SHCSR - The SVCall pending bit, reads as 1 if the exception is pending */
	uint32_t memFaultEna    :  1;   /**< SHCSR - The MemManage enable bit, set to 1 to enable */
	uint32_t busFaultEna    :  1;   /**< SHCSR - The BusFault enable bit, set to 1 to enable */
	uint32_t usgFaultEna    :  1;   /**< SHCSR - The UsageFault enable bit, set to 1 to enable */
	uint32_t reserved4      : 13;   /**< Reserved */
} stc_fault_shcsr_t;
/** The fault configuration structure. */
typedef struct
{
	uint32_t r0;       /**< R0 register content */
	uint32_t r1;       /**< R1 register content */
	uint32_t r2;       /**< R2 register content */
	uint32_t r3;       /**< R3 register content */
	uint32_t r12;      /**< R12 register content */
	uint32_t lr;       /**< LR register content */
	uint32_t pc;       /**< PC register content */
	uint32_t psr;      /**< PSR register content */
	//CORTEX_M4
#if 0
	union
	{
		uint32_t cfsrReg;              	/**< CFSR register content as a word */
		stc_fault_cfsr_t cfsrBits;  	/**< CFSR register content as a structure */
	} cfsr;
	union
	{
		uint32_t hfsrReg;              	/**< HFSR register content as a word */
		stc_fault_hfsr_t hfsrBits;  	/**< HFSR register content as a structure */
	} hfsr;
	union
	{
		uint32_t shcsrReg;              /**< SHCSR register content as a word */
		stc_fault_shcsr_t shcsrBits; 	/**< SHCSR register content as a structure */
	} shcsr;

	uint32_t mmfar;                		/**< MMFAR register content */
	uint32_t bfar;                 		/**< BFAR register content */
#endif
} stc_fault_frame_t;

